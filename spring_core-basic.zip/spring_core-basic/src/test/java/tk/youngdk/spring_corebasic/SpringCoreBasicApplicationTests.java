package tk.youngdk.spring_corebasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
